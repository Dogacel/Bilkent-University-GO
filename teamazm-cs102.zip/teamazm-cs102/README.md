# TeamAZM-cs102
BuGo
Description: Every year, over two thousand students are struggling to find their way through the campus and classrooms. With the slightly confusing information of so many buildings and paths, it might be exhausting to discover the campus all by yourself. To help people during this trickish journey, project BUGO (Bilkent University Go), an Android Application is designed to provide the users with many convenient features.

